# Students API

Simple API built with Python and Flask.

## Requirements
- Python 3
- Flask

## Installation

```bash
pip install -r requirements.txt
